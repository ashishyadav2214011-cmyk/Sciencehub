ScienceHub Integrated Live Logo

Reference:
- sciencehub-logo-reference.png = user-provided locked visual reference.

Live implementation:
- sciencehub-logo-live.html
- DNA rotates 360 degrees every 3 seconds.
- Exactly 6 luminous electron particles move continuously.
- Electrons use independent paths, phases and speeds.
- No e-minus text is used for the particles.
- Central character, brain/intelligence motif, open book, SH signature and rounded frame preserve the integrated identity.

Note: the orbital paths are a visual metaphor, not a literal quantum-mechanical simulation.
