# ScienceHub — Ashu.Ayansh
Mobile-first personal Study OS foundation.

Included: Home, Study tasks, Subjects, Practice, Revision, Progress, Time Tracking, My Space notes, native Share API, data export/reset, local persistence and offline PWA caching, plus Academic, Learning, School, Career and PCB Opportunities sections.

This is a working coded foundation. The complete locked blueprint includes deeper backend/AI/cloud integrations that require a real backend and external services; those are not falsely represented as already implemented here.

For PWA installation/offline behavior, serve over HTTPS (or localhost).
