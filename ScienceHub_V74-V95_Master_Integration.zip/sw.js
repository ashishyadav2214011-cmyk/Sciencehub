const CACHE="sciencehub-v95-master-cache";
const ASSETS=["./","./index.html","./style.css","./app.js","./sciencehub-v95-integration.js","./sciencehub-perspective.js","./perspective.css","./sciencehub-enhancements.js","./sciencehub-live-icon.js","./sciencehub-live-icon.css","./manifest.json","./assets/brand/sciencehub-icon-192.png","./assets/brand/sciencehub-icon-512.png"];
self.addEventListener("install",e=>e.waitUntil(caches.open(CACHE).then(c=>c.addAll(ASSETS)).then(()=>self.skipWaiting())));
self.addEventListener("activate",e=>e.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k!==CACHE).map(k=>caches.delete(k)))).then(()=>self.clients.claim())));
self.addEventListener("fetch",e=>{if(e.request.method!=="GET")return;e.respondWith(caches.match(e.request).then(c=>c||fetch(e.request).then(r=>{const cp=r.clone();caches.open(CACHE).then(x=>x.put(e.request,cp)).catch(()=>{});return r}).catch(()=>caches.match("./index.html"))))});
