# ScienceHub V80

Historical source patch is not preserved as a separate executable file in the current repository snapshot; this version slot is retained so the lineage remains explicit without inventing features.

**Cumulative integration target:** V95 Master Integration.
