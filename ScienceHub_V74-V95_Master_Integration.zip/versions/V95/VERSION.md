# ScienceHub V95

Master integration release: schema bridge, Perspective, cache namespace, manifest and live icon integration.

**Cumulative integration target:** V95 Master Integration.
