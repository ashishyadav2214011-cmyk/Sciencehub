ScienceHub App Icon — Live Orbital V1

Integrated files:
- assets/brand/sciencehub-icon-192.png
- assets/brand/sciencehub-icon-512.png
- sciencehub-live-icon.js
- sciencehub-live-icon.css
- sciencehub-icon-live.html (standalone preview)
- patched index.html

Animation:
- 4 clean elliptical orbital paths
- 1 glowing electron/node per path
- 360° revolution every 3.5 seconds
- continuous real-time loop
- thin orbital lines and subtle tails
- 10-second preview marker; it does not stop the live orbit

Important PWA note:
The installed Android/PWA launcher icon itself is a static PNG because standard manifest icons are static. The real-time animated version runs inside the ScienceHub UI/header and in the included live preview page.
